import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Profile",
          style: TextStyle(color: Colors.white,fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black87,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.teal[100],
                      child: Icon(Icons.person, size: 50, color: Colors.black87),
                    ),
                    SizedBox(height: 15),
                    Text(
                      "User Name",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                        color: Colors.black87,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      "username@gmail.com",
                      style: TextStyle(fontSize: 16, color: Colors.black87),
                    ),
                    SizedBox(height: 15),
                    ElevatedButton(
                      onPressed: () {
                        // Edit Profile action
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal[400],
                        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                      child: Text(
                        "Edit Profile",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),
            ListTile(
              title: Text(
                "Your Events",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.teal[800]),
              ),
              trailing: Icon(Icons.arrow_forward_ios, color: Colors.teal[400]),
              onTap: () {
                Navigator.pushNamed(context, '/eventList');
              },
            ),
            Divider(color: Colors.grey[300]),
            ListTile(
              title: Text(
                "My Pledged Gifts",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.teal[800]),
              ),
              trailing: Icon(Icons.arrow_forward_ios, color: Colors.teal[400]),
              onTap: () {
                Navigator.pushNamed(context, '/pledgedGifts');
              },
            ),
          ],
        ),
      ),
    );
  }
}
