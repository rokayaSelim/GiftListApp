import 'package:flutter/material.dart';

class GiftListPage extends StatefulWidget {
  @override
  _GiftListPageState createState() => _GiftListPageState();
}

class _GiftListPageState extends State<GiftListPage> {
  List<Map<String, dynamic>> gifts = [
    {"name": "Smartphone", "category": "Electronics", "status": "Available"},
    {"name": "Book", "category": "Literature", "status": "Pledged"},
    {"name": "Headphones", "category": "Electronics", "status": "Available"},
    {"name": "Novel", "category": "Literature", "status": "Received"},
  ];

  String sortBy = 'name'; // Default sorting by name

  // Function to sort the gift list based on the selected criteria
  void sortGifts(String criteria) {
    setState(() {
      sortBy = criteria;
      if (criteria == 'name') {
        gifts.sort((a, b) => a['name'].compareTo(b['name']));
      } else if (criteria == 'category') {
        gifts.sort((a, b) => a['category'].compareTo(b['category']));
      } else if (criteria == 'status') {
        gifts.sort((a, b) => a['status'].compareTo(b['status']));
      }
    });
  }

  // Function to show dialog for adding a new gift
  void _showAddGiftDialog() {
    final TextEditingController giftNameController = TextEditingController();
    final TextEditingController giftCategoryController = TextEditingController();
    String selectedStatus = 'Available';

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Gift'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: giftNameController,
                decoration: InputDecoration(labelText: 'Gift Name'),
              ),
              TextField(
                controller: giftCategoryController,
                decoration: InputDecoration(labelText: 'Category'),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField<String>(
                value: selectedStatus,
                items: ['Available', 'Pledged', 'Received']
                    .map((status) => DropdownMenuItem(
                  value: status,
                  child: Text(status),
                ))
                    .toList(),
                onChanged: (value) {
                  if (value != null) {
                    selectedStatus = value;
                  }
                },
                decoration: InputDecoration(labelText: 'Status'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (giftNameController.text.isNotEmpty && giftCategoryController.text.isNotEmpty) {
                  setState(() {
                    gifts.add({
                      "name": giftNameController.text,
                      "category": giftCategoryController.text,
                      "status": selectedStatus,
                    });
                  });
                }
                Navigator.pop(context);
              },
              child: Text('Add', style: TextStyle(color: Colors.teal)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        );
      },
    );
  }

  void _showEditGiftDialog(int index) {
    final TextEditingController giftNameController = TextEditingController(text: gifts[index]['name']);
    final TextEditingController giftCategoryController = TextEditingController(text: gifts[index]['category']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Gift'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: giftNameController,
                decoration: InputDecoration(labelText: 'Gift Name'),
              ),
              TextField(
                controller: giftCategoryController,
                decoration: InputDecoration(labelText: 'Category'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  gifts[index]['name'] = giftNameController.text;
                  gifts[index]['category'] = giftCategoryController.text;
                });
                Navigator.pop(context);
              },
              child: Text('Save', style: TextStyle(color: Colors.teal)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        );
      },
    );
  }

  void _showDeleteConfirmationDialog(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete Gift'),
          content: Text('Are you sure you want to delete this gift?'),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  gifts.removeAt(index);
                });
                Navigator.pop(context);
              },
              child: Text('Delete', style: TextStyle(color: Colors.red)),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Gift List',
          style: TextStyle(color: Colors.white,fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black87,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Sorting Dropdown and Add Button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                DropdownButton<String>(
                  value: sortBy,
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      sortGifts(newValue);
                    }
                  },
                  items: <String>['name', 'category', 'status']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text('Sort by $value', style: TextStyle(color: Colors.teal)),
                    );
                  }).toList(),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black87,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                  ),
                  onPressed: _showAddGiftDialog,
                  child: Text("Add New Gift", style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
            SizedBox(height: 20),

            // Gift List
            Expanded(
              child: ListView.builder(
                itemCount: gifts.length,
                itemBuilder: (context, index) {
                  final gift = gifts[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 6,
                      child: ListTile(
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        title: Text(
                          gift['name'],
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                        ),
                        subtitle: Text(
                          'Category: ${gift['category']} - Status: ${gift['status']}',
                          style: TextStyle(color: Colors.teal[700]),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit, color: Colors.black87),
                              onPressed: () {
                                _showEditGiftDialog(index);
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.redAccent),
                              onPressed: () {
                                _showDeleteConfirmationDialog(index);
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.arrow_forward_ios, color: Colors.teal[400]),
                              onPressed: () {
                                Navigator.pushNamed(context, '/giftDetails');
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
