import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  // List of friends with names and friend request statuses
  final List<Map<String, dynamic>> friends = [
    {"name": "Alice Johnson", "upcomingEvents": 3, "hasFriendRequest": true},
    {"name": "Bob Smith", "upcomingEvents": 1, "hasFriendRequest": false},
    {"name": "Catherine Lee", "upcomingEvents": 2, "hasFriendRequest": true},
    {"name": "David Brown", "upcomingEvents": 4, "hasFriendRequest": false},
    {"name": "Emma Wilson", "upcomingEvents": 0, "hasFriendRequest": true},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Hedieaty',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.person, size: 35, color: Colors.white),
            onPressed: () {
              Navigator.pushNamed(context, '/profile');
            },
          ),
        ],
        backgroundColor: Colors.black87,
        elevation: 0,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.pushNamed(context, '/eventList');
        },
        label: Text(
          'Create Event/List',
          style: TextStyle(fontSize: 16, color: Colors.white),
        ),
        icon: Icon(Icons.add, color: Colors.white),
        backgroundColor: Colors.black87,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Colors.black87,
            padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 20.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 5,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search Friends',
                  hintStyle: TextStyle(color: Colors.black87),
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.search, color: Colors.teal[400]),
                  contentPadding: EdgeInsets.only(top: 12),
                ),
              ),
            ),
          ),
          SizedBox(height: 18),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              'Friends',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
          ),
          SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: friends.length,
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              itemBuilder: (context, index) {
                final friend = friends[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: ListTile(
                      leading: CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.teal[50],
                        child: Icon(Icons.person, size: 40, color: Colors.black87),
                      ),
                      title: Text(
                        friend['name'],
                        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18, color: Colors.black87),
                      ),
                      subtitle: Text(
                        'Upcoming Events: ${friend['upcomingEvents']}',
                        style: TextStyle(color: Colors.teal[600], fontSize: 15),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (friend['hasFriendRequest'])
                            Icon(Icons.person_add, color: Colors.orangeAccent),
                          SizedBox(width: 10),
                          IconButton(
                            icon: Icon(Icons.arrow_forward_ios, color: Colors.teal[400]),
                            onPressed: () {
                              Navigator.pushNamed(context, '/eventList');
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
