import 'package:flutter/material.dart';

class PledgedGiftsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Pledged Gifts'),
      ),
      body: ListView.builder(
        itemCount: 5, // Replace with pledged gifts count
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Gift ${index + 1}'),
            subtitle: Text('Friend Name | Due: Tomorrow'),
          );
        },
      ),
    );
  }
}
