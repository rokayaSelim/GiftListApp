import 'package:flutter/material.dart';

class EventListPage extends StatefulWidget {
  @override
  _EventListPageState createState() => _EventListPageState();
}

class _EventListPageState extends State<EventListPage> {
  List<Map<String, dynamic>> events = [
    {"name": "Birthday Party", "category": "Personal", "status": "Upcoming"},
    {"name": "Team Meeting", "category": "Work", "status": "Current"},
    {"name": "Wedding", "category": "Personal", "status": "Past"},
    // Add more events here
  ];

  String sortBy = 'name';

  void sortEvents(String criteria) {
    setState(() {
      sortBy = criteria;
      if (criteria == 'name') {
        events.sort((a, b) => a['name'].compareTo(b['name']));
      } else if (criteria == 'category') {
        events.sort((a, b) => a['category'].compareTo(b['category']));
      } else if (criteria == 'status') {
        events.sort((a, b) => a['status'].compareTo(b['status']));
      }
    });
  }

  void _showAddEventDialog() {
    final TextEditingController eventNameController = TextEditingController();
    final TextEditingController eventCategoryController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add New Event'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: eventNameController,
                decoration: InputDecoration(labelText: 'Event Name'),
              ),
              TextField(
                controller: eventCategoryController,
                decoration: InputDecoration(labelText: 'Category'),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal[400],
              ),
              onPressed: () {
                if (eventNameController.text.isNotEmpty && eventCategoryController.text.isNotEmpty) {
                  setState(() {
                    events.add({
                      "name": eventNameController.text,
                      "category": eventCategoryController.text,
                      "status": "Upcoming" // Default status for new events
                    });
                  });
                }
                Navigator.pop(context);
              },
              child: Text('Add'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        );
      },
    );
  }

  void _showEditEventDialog(int index) {
    final TextEditingController eventNameController = TextEditingController(text: events[index]['name']);
    final TextEditingController eventCategoryController = TextEditingController(text: events[index]['category']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Edit Event'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: eventNameController,
                decoration: InputDecoration(labelText: 'Event Name'),
              ),
              TextField(
                controller: eventCategoryController,
                decoration: InputDecoration(labelText: 'Category'),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
              ),
              onPressed: () {
                setState(() {
                  events[index]['name'] = eventNameController.text;
                  events[index]['category'] = eventCategoryController.text;
                });
                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
          ],
        );
      },
    );
  }

  void deleteEvent(int index) {
    setState(() {
      events.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Events',
          style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black87,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Sorting options and Add Event button
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                DropdownButton<String>(
                  value: sortBy,
                  onChanged: (String? newValue) {
                    if (newValue != null) sortEvents(newValue);
                  },
                  items: <String>['name', 'category', 'status']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text('Sort by $value', style: TextStyle(color: Colors.teal[800])),
                    );
                  }).toList(),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black87,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
                  ),
                  onPressed: _showAddEventDialog,
                  child: Text("Add New Event", style: TextStyle(color: Colors.white, fontSize: 16)),
                ),
              ],
            ),
            SizedBox(height: 20),

            // Event List
            Expanded(
              child: ListView.builder(
                itemCount: events.length,
                itemBuilder: (context, index) {
                  final event = events[index];
                  return Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    margin: EdgeInsets.symmetric(vertical: 8),
                    elevation: 3,
                    color: event['status'] == 'Past'
                        ? Colors.white60
                        : Colors.white, // Color-coded for Past events
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      title: Text(
                        event['name'],
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                      ),
                      subtitle: Text(
                        'Category: ${event['category']} | Status: ${event['status']}',
                        style: TextStyle(color: Colors.teal[700]),
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.black87),
                            onPressed: () {
                              _showEditEventDialog(index);
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.redAccent),
                            onPressed: () {
                              deleteEvent(index);
                            },
                          ),
                          IconButton(
                            icon: Icon(Icons.arrow_forward_ios, color: Colors.teal[400]),
                            onPressed: () {
                              Navigator.pushNamed(context, '/giftList');
                            },
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
